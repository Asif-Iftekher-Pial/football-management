<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
     <!-- Bootstrap CSS-->
     <link href="{{ asset('admin_essentials/vendor/bootstrap-4.1/bootstrap.min.css') }}" rel="stylesheet" media="all">

</head>
<body>
    <h5>Your subscription cancled</h5>
    <a href="{{ route('dashboard') }}" class="btn btn-sm btn-primary">Return To Dashboard</a>
</body>
</html>