<header class="header-desktop">
    <div class="section__content section__content--p30">
        <div class="container-fluid">
            <div class="header-wrap">
                <form class="form-header" action="" method="POST">
                    
                    

                    <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasExactRoles', 'registered_football_club')): ?>
                    <a href="<?php echo e(route('paypalPage')); ?>" class="btn btn-outline-warning">pay Now</a>
                    <?php endif; ?>

                </form>
                <div class="header-button">
                    
                   
                    <div class="account-wrap">
                        <div class="account-item clearfix js-item-menu">
                            <div class="image">
                                <img src="<?php echo e(asset('images/'.Auth::user()->photo)); ?>" alt="<?php echo e(Auth::user()->name); ?>" />
                            </div>
                            <div class="content">
                                <a class="js-acc-btn" href="#"><?php echo e(Auth::user()->name); ?></a>
                            </div>
                            <div class="account-dropdown js-dropdown">
                                <div class="info clearfix">
                                    <div class="image">
                                        <a href="#">
                                            <img src="<?php echo e(asset('images/'.Auth::user()->photo)); ?>" alt="<?php echo e(Auth::user()->name); ?>" />
                                        </a>
                                    </div>
                                    <div class="content">
                                        <h5 class="name">
                                            <a href="#"><?php echo e(Auth::user()->name); ?></a>
                                        </h5>
                                        <span class="email"><?php echo e(Auth::user()->email); ?></span>
                                        <span class="email">Roles: <?php echo e(Auth::user()->getRoleNames()); ?></span>
                                    </div>
                                </div>
                                
                                <div class="account-dropdown__footer">
                                    <a href="<?php echo e(route('logout')); ?>">
                                        <i class="zmdi zmdi-power"></i>Logout</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header><?php /**PATH E:\My projects\Client Project\footballGroupCompany\resources\views/layouts/header.blade.php ENDPATH**/ ?>