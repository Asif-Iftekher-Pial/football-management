<?php if(session()->has('message')): ?>
<div class="alert alert-success alert-dismissible fade show" role="alert" id="alert">
    <?php echo e(session()->get('message')); ?>

    
</div>
<?php endif; ?>

<?php if(session()->has('error')): ?>
<div class="alert alert-danger alert-dismissible fade show" role="alert" id="alert">
    <?php echo e(session()->get('error')); ?>

    
</div>
<?php endif; ?>

<?php if($errors->any()): ?>
<div class="alert alert-danger" id="alert">
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?><?php /**PATH E:\My projects\Client Project\footballGroupCompany\resources\views/layouts/errorAndSuccessMessage.blade.php ENDPATH**/ ?>