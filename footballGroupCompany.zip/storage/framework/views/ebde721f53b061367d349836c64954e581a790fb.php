
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="au-card recent-report">
                <div class="au-card-inner">
                    <?php echo $__env->make('layouts.errorAndSuccessMessage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="overview-wrap">
                        <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasAllRoles', $collectionOfRoles)): ?>
                            <h2 class="title-1">Football Clubs</h2>

                            <a href="<?php echo e(route('football-club.create')); ?>" class="au-btn au-btn-icon au-btn--blue">
                                <i class="zmdi zmdi-plus"></i>Add Football Club</a>
                        <?php else: ?>
                        <?php endif; ?>

                        <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasExactRoles', 'registered_football_club')): ?>
                            <h2 class="title-1">Club Information</h2>
                        <?php endif; ?>

                        <?php if(
                            (auth()->user()->hasRole('football_group_staff') || auth()->user()->hasRole('partner')) &&
                                !auth()->user()->hasallroles($collectionOfRoles)): ?>
                            <h2 class="title-1">Club</h2>
                        <?php endif; ?>

                    </div>
                    <?php if(auth()->user()->hasRole('partner') ||
                            auth()->user()->hasRole('football_group_staff') ||
                            auth()->user()->hasallroles($collectionOfRoles)): ?>
                        <div class="row m-t-30">
                            <div class="col-md-12">
                                <!-- DATA TABLE-->
                                <div class="table-responsive m-b-40">
                                    <table class="table table-borderless table-data3" id="myTable">
                                        <thead>
                                            <tr>
                                                <th>Name</th>
                                                <th>Photo</th>
                                                <th>Country</th>
                                                <th>Website</th>
                                                <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasAllRoles', $collectionOfRoles)): ?>
                                                    <th>Is_Approved</th>
                                                    <th>Payment Status</th>
                                                <?php endif; ?>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $all_football_clubs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $football_club): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($football_club->name); ?></td>
                                                    <td>
                                                        <?php if($football_club->user->photo): ?>
                                                            <img src="<?php echo e(asset('images/' . $football_club->user->photo)); ?>"
                                                                alt="Photo" width="100px">
                                                        <?php else: ?>
                                                            No Photo
                                                        <?php endif; ?>
                                                    </td>
                                                    <td><?php echo e($football_club->country); ?></td>
                                                    <td><?php echo e($football_club->website); ?></td>
                                                    <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasAllRoles', $collectionOfRoles)): ?>
                                                        <td>
                                                            <div class="dropdown">
                                                                <button
                                                                    class="btn btn-sm <?php echo e($football_club->status == 'approved' ? 'btn-success' : 'btn-danger'); ?> dropdown-toggle"
                                                                    type="button" id="dropdownMenuButton"
                                                                    data-toggle="dropdown" aria-haspopup="true"
                                                                    aria-expanded="false">
                                                                    <?php echo e(ucwords(str_replace('_', ' ', $football_club->status))); ?>

                                                                </button>
                                                                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                                                    <a class="dropdown-item"
                                                                        href="<?php echo e(route('football_club.approve.status', ['id' => $football_club->id, 'status' => 'approved'])); ?>">Approved</a>
                                                                    <a class="dropdown-item"
                                                                        href="<?php echo e(route('football_club.approve.status', ['id' => $football_club->id, 'status' => 'not_approved'])); ?>">Reject</a>

                                                                </div>
                                                            </div>

                                                        </td>
                                                        <td>
                                                            <div>
                                                                <?php if($football_club->payment == 'not_paid'): ?>
                                                                    <a href="<?php echo e(route('sendPaypalPaymentLink', $football_club->user->id)); ?>"
                                                                        class="btn btn-sm btn-outline-primary"><i
                                                                            class="fa fa-envelope m-1"
                                                                            aria-hidden="true"></i>Payment Link</a>
                                                                <?php else: ?>
                                                                <?php endif; ?>
                                                                <div class="row">
                                                                    <div class="dropdown">
                                                                        <button
                                                                            class="btn btn-sm <?php echo e($football_club->payment == 'paid' ? 'btn-success' : 'btn-danger'); ?> dropdown-toggle"
                                                                            type="button" id="dropdownMenuButton"
                                                                            data-toggle="dropdown" aria-haspopup="true"
                                                                            aria-expanded="false">
                                                                            <?php echo e(ucwords(str_replace('_', ' ', $football_club->payment))); ?>

                                                                        </button>
                                                                        <div class="dropdown-menu"
                                                                            aria-labelledby="dropdownMenuButton">
                                                                            <a class="dropdown-item"
                                                                                href="<?php echo e(route('football_club.payment.status', ['id' => $football_club->id, 'status' => 'paid'])); ?>">Paid</a>
                                                                            <a class="dropdown-item"
                                                                                href="<?php echo e(route('football_club.payment.status', ['id' => $football_club->id, 'status' => 'not_paid'])); ?>">Not
                                                                                Paid</a>
    
                                                                        </div>
                                                                    </div>
    
                                                                    <p class="text-<?php echo e($football_club->payment == 'paid' ? 'success' : 'danger'); ?> m-2">
                                                                        <?php echo e($football_club->payment); ?></p>
                                                                </div>
                                                                
                                                            </div>

                                                        </td>
                                                    <?php endif; ?>
                                                    
                                                    <td class="row justify-content-between">
                                                        
                                                        <a href="<?php echo e(route('football-club.show', $football_club->id)); ?>"
                                                            class="btn btn-success btn-sm"><i class="fa fa-eye"
                                                                aria-hidden="true"></i></a>
                                                        <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasAllRoles', $collectionOfRoles)): ?>
                                                            <a href="<?php echo e(route('football-club.edit', $football_club->id)); ?>"
                                                                class="btn btn-warning btn-sm"><i class="fa fa-pencil-square-o"
                                                                    aria-hidden="true"></i></a>
                                                            
                                                        <?php endif; ?>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                                <!-- END DATA TABLE-->
                            </div>
                        </div>
                    <?php else: ?>
                    <?php endif; ?>




                    <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasExactRoles', 'registered_football_club')): ?>
                        <div class="row m-t-30">
                            <div class="col-md-12">
                                <div class="card text-center">
                                    <div class="card-header">
                                        <?php if($football_club->football_club->status == 'approved'): ?>
                                            <a href="<?php echo e(route('football-club.edit', $football_club->football_club->id)); ?>"
                                                class="btn btn-warning pull-left m-1"><i class="fa fa-pencil-square-o"
                                                    aria-hidden="true"></i>
                                            </a>
                                        <?php else: ?>
                                            <p>Get aprroved by admin to edit your profile</p>
                                        <?php endif; ?>


                                        <i class="fa fa-user"></i>
                                        <strong class="card-title mb-3">Club Profile</strong>

                                        <a href="<?php echo e(route('football_club.export.pdf', $football_club->football_club->id)); ?>"
                                            class="btn btn-success pull-right"><i class="fa fa-print"
                                                aria-hidden="true"></i></a>
                                    </div>
                                    <div class="card-body">
                                        <div class="mx-auto d-block">
                                            <?php if($football_club->photo): ?>
                                                <img class="rounded-circle mx-auto d-block"
                                                    src="<?php echo e(asset('images/' . $football_club->photo)); ?>" alt="Photo"
                                                    width="100px">
                                            <?php else: ?>
                                                No Photo
                                            <?php endif; ?>
                                            <h5 class="text-sm-center mt-2 mb-1">Name: <?php echo e($football_club->name); ?></h5>
                                            <h5 class="text-sm-center mt-2 mb-1">Email: <?php echo e($football_club->email); ?></h5>
                                            <h5 class="text-sm-center mt-2 mb-1">Phone:
                                                <?php echo e($football_club->football_club->phone); ?></h5>
                                            <p class="text-sm-center mt-2 mb-1">Address:
                                                <?php echo e($football_club->football_club->address); ?></p>
                                            <p class="text-sm-center mt-2 mb-1">Country:
                                                <?php echo e($football_club->football_club->country); ?></p>
                                            <p class="location text-sm-center">Contact:
                                                <?php echo e($football_club->football_club->contact); ?></p>
                                            <p class="location text-sm-center ">Payment Status:
                                            <p
                                                class="text-<?php echo e($football_club->football_club->payment == 'paid' ? 'success' : 'danger'); ?>">
                                                <?php echo e(ucwords(str_replace('_', ' ', $football_club->football_club->payment))); ?>

                                            </p>
                                            </p>
                                        </div>
                                        <hr>

                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div id="paypal-button-container-P-49L33337L23055829MXYFE6Y"></div>
    
   
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script src="https://www.paypal.com/sdk/js?client-id=sb&vault=true&intent=subscription" data-sdk-integration-source="button-factory"></script>
<script>
paypal.Buttons({
    style: {
        shape: 'rect',
        color: 'gold',
        layout: 'vertical',
        label: 'subscribe'
    },
    createSubscription: function(data, actions) {
        return actions.subscription.create({
        /* Creates the subscription */
        plan_id: 'P-49L33337L23055829MXYFE6Y'
        });
    },
    onApprove: function(data, actions) {
        alert(data.subscriptionID); // You can add optional success message for the subscriber here
    }
}).render('#paypal-button-container-P-49L33337L23055829MXYFE6Y'); // Renders the PayPal button
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\My projects\Client Project\footballGroupCompany\resources\views/partials/football_club/index.blade.php ENDPATH**/ ?>