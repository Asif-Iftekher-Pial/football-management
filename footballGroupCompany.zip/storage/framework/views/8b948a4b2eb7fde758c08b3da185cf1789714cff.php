
<?php $__env->startSection('content'); ?>
<div class="col-lg-12">
    <div class="card">
        <div class="card-header">
            <strong>Football Group Staff Edit</strong>
        </div>
        <div class="card-body card-block">
            <form action="<?php echo e(route('football-group-staff.update', $football_group_staff->id)); ?>" method="post" enctype="multipart/form-data">
                <?php echo method_field('patch'); ?>
                <?php echo csrf_field(); ?>
                <?php echo $__env->make('layouts.errorAndSuccessMessage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="name" class=" form-control-label">Club Name</label>
                            <input type="text" name="name" value="<?php echo e($football_group_staff->name); ?>" placeholder="Enter your club name" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="contact" class=" form-control-label">Contact</label>
                            <input type="number" name="contact" value="<?php echo e($football_group_staff->contact); ?>" placeholder="Enter contact number" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="address" class=" form-control-label">Address</label>
                            <input name="address" value=<?php echo e($football_group_staff->address); ?> class="form-control"></input>
                        </div>
                        <div class="form-group">
                            <label for="website" class=" form-control-label">Website</label>
                            <input name="website" value="<?php echo e($football_group_staff->website); ?>"  placeholder="https://www.yourwebsite.com"  class="form-control">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="telephone" class=" form-control-label">Telephone</label>
                            <input type="text" name="telephone" value="<?php echo e($football_group_staff->telephone); ?>" placeholder="Enter your telephone" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="country" class=" form-control-label">Country</label>
                            <input type="text" name="country" value="<?php echo e($football_group_staff->country); ?>" placeholder="USA" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="password" class=" form-control-label">Password</label>
                            <input type="password" name="password"  class="form-control">
                        </div>
                       
                        <div class="form-group">
                            <label for="photo" class="form-control-label">Photo</label>
                            <input type="file" id="file-input" name="photo" class="form-control-file">
                        </div>
                       
                    </div>
                </div>
                
                    <button type="submit" class="btn btn-primary btn-sm">
                        <i class="fa fa-dot-circle-o"></i> Submit
                    </button>
                
            </form>
           
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\My projects\Client Project\footballGroupCompany\resources\views/partials/football_group_staff/edit.blade.php ENDPATH**/ ?>