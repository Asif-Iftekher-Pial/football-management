
<?php $__env->startSection('content'); ?>
<div class="row">

    <div class="col-lg-12">
        <div class="au-card recent-report">
            <div class="au-card-inner">
                <div class="overview-wrap">
                    <h2 class="title-1">Users</h2>
                   
                            
                </div>
                <div class="row m-t-30">

                    <div class="col-md-12">
                        <?php echo $__env->make('layouts.errorAndSuccessMessage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <a href="<?php echo e(route('player.create')); ?>" class="btn btn-sm btn-success">
                            <i class="zmdi zmdi-plus"></i>Players</a>
                            <a href="<?php echo e(route('football-group-staff.create')); ?>" class="btn btn-sm btn-primary">
                                <i class="zmdi zmdi-plus"></i>Football Group Staff</a>
                                <a href="<?php echo e(route('manager.create')); ?>" class="btn btn-sm btn-warning">
                                    <i class="zmdi zmdi-plus"></i>Manager</a>
                                    <a href="<?php echo e(route('group-partner.create')); ?>" class="btn btn-sm btn-warning">
                                        <i class="zmdi zmdi-plus"></i>Group Partner</a>
                        <!-- DATA TABLE-->
                        <div class="table-responsive m-b-40 mt-3">
                            <table class="table table-borderless table-data3" id="myTable">
                                <thead>
                                    <tr>
                                        <th style="text-align: left;">User Name</th>
                                        <th style="text-align: left;">User Email</th>
                                        <th style="text-align: left;">Assign Role</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td style="text-align: left;"><?php echo e($user->name); ?></td>
                                    <td style="text-align: left;"><?php echo e($user->email); ?></td>
                                    <td style="text-align: left;">
                                        <a style="display: <?php echo e($user->id == 1 ? 'none' : ''); ?>" href="<?php echo e(route('assignRoleToUser',$user->id)); ?>" class="btn btn-sm btn-primary">
                                            <i class="zmdi zmdi-plus"></i></a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <!-- END DATA TABLE-->
                    </div>
                </div>
            </div>
        </div>
    </div>




    <div class="col-lg-12">
        <div class="au-card recent-report">
            <div class="au-card-inner">
                <div class="overview-wrap">
                    <h2 class="title-1">Roles</h2>
                    
                </div>
                <div class="row m-t-30">
                    <div class="col-md-12">
                        <!-- DATA TABLE-->
                        <div class="table-responsive m-b-40">
                            <table class="table table-borderless table-data3" id="myTable">
                                <thead>
                                    <tr>
                                        <th style="text-align: left;">Name</th>
                                        
                                    </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td style="text-align: left;"><?php echo e($role->name); ?></td>
                                    
                                </tr>
                                

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <!-- END DATA TABLE-->
                    </div>
                </div>
            </div>
        </div>
    </div>
    
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\My projects\Client Project\footballGroupCompany\resources\views/partials/Roles_permissions/index.blade.php ENDPATH**/ ?>