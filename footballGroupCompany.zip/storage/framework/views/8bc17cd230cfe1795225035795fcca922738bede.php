<aside class="menu-sidebar d-none d-lg-block">
    <div class="logo">
        <a href="<?php echo e(route('dashboard')); ?>">
            <img src="<?php echo e(asset('logo/header.png')); ?>" class="test"
                style="max-width: 115%;
            height: auto;
            margin-left: -12px;
            margin-bottom: 5px;"
                alt="Cool Admin" />
        </a>
    </div>
    <div class="menu-sidebar__content js-scrollbar1">
        <nav class="navbar-sidebar">
            <ul class="list-unstyled navbar__list">
                <li class="active has-sub">
                    <a class="js-arrow" href="<?php echo e(route('dashboard')); ?>">
                        <i class="fas fa-tachometer-alt"></i>Dashboard</a>

                </li>
                <li style="display:<?php echo e(haveAllRoles_super_admin() ? '' : 'none'); ?>">
                    <a href="<?php echo e(route('roles-permissions.index')); ?>">
                        <i class="far fa-check-square"></i>Users & Roles</a>
                </li>

                <?php if(auth()->user()->hasRole('football_group_staff') || auth()->user()->hasRole('partner')): ?>
                    <li>
                        <a href="<?php echo e(route('football-group-staff.index')); ?>">
                            <i class="fas fa-chart-bar"></i>Football Group Staff</a>
                    </li>
                <?php else: ?>
                <?php endif; ?>

                <?php if(auth()->user()->hasRole('football_group_staff') || auth()->user()->hasRole('partner')): ?>
                    <li>
                        <a href="<?php echo e(route('group-partner.index')); ?>">
                            <i class="fas fa-chart-bar"></i>Football Group Partner</a>
                    </li>
                <?php else: ?>
                <?php endif; ?>

                <?php if(auth()->user()->hasRole('player') ||
                        auth()->user()->hasRole('football_group_staff') ||
                        auth()->user()->hasRole('partner')): ?>
                    <li>
                        <a href="<?php echo e(route('player.index')); ?>"><i class="fa fa-users"></i>Players</a>
                    </li>
                <?php else: ?>
                <?php endif; ?>
                <?php if(auth()->user()->hasRole('manager') ||
                        auth()->user()->hasRole('football_group_staff') ||
                        auth()->user()->hasRole('partner')): ?>
                    <li>
                        <a href="<?php echo e(route('manager.index')); ?>"><i class="fas fa-user"></i>Manager</a>
                    </li>
                <?php else: ?>
                <?php endif; ?>

                <?php if(auth()->user()->hasRole('other_football_job') ||
                        auth()->user()->hasRole('football_group_staff') ||
                        auth()->user()->hasRole('partner')): ?>
                    <li>
                        <a href="<?php echo e(route('other-football-job.index')); ?>"><i class="fas fa-user"></i>Other Football
                            Job</a>
                    </li>
                <?php else: ?>
                <?php endif; ?>

                <?php if(auth()->user()->hasRole('other_football_job') ||
                        auth()->user()->hasRole('football_group_staff') ||
                        auth()->user()->hasRole('partner') ||
                        auth()->user()->hasRole('registered_football_club')): ?>
                    <li>
                        <a href="<?php echo e(route('football-club.index')); ?>"><i class="fas fa-user"></i>Football Club</a>
                    </li>
                <?php else: ?>
                <?php endif; ?>

                <?php if(auth()->user()->hasexactroles('registered_football_club')): ?>
                    <li>
                        <a href="<?php echo e(route('player.list')); ?>"><i class="fas fa-user"></i>Pick Players</a>
                    </li>
                <?php else: ?>
                <?php endif; ?>

                <?php if(auth()->user()->hasexactroles('registered_football_club')): ?>
                    <li>
                        <a href="<?php echo e(route('manager.list')); ?>"><i class="fas fa-user"></i>Pick Manager</a>
                    </li>
                <?php else: ?>
                <?php endif; ?>


                <li style="display:<?php echo e(haveAllRoles_super_admin() ? '' : 'none'); ?>">
                    <a href="<?php echo e(route('all.players.with.clubs')); ?>"><i class="fas fa-user"></i>Selected Players By
                        Clubs</a>
                </li>

                <li style="display:<?php echo e(haveAllRoles_super_admin() ? '' : 'none'); ?>">
                    <a href="<?php echo e(route('all.managers.with.clubs')); ?>"><i class="fas fa-user"></i>Selected Managers By
                        Clubs</a>
                </li>









                
            </ul>
        </nav>
    </div>
</aside>
<?php /**PATH E:\My projects\Client Project\footballGroupCompany\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>