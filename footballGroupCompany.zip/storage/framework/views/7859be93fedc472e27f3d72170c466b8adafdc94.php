
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12">
        <div class="au-card recent-report">
            <div class="au-card-inner">
                <?php echo $__env->make('layouts.errorAndSuccessMessage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="overview-wrap">
                    <h2 class="title-1">Football Group Staff</h2>
                    <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasAllRoles', $collectionOfRoles)): ?>
                    <a href="<?php echo e(route('football-group-staff.create')); ?>" class="au-btn au-btn-icon au-btn--blue">
                        <i class="zmdi zmdi-plus"></i>add staff</a>
                    <?php endif; ?>
                    
                </div>
                <div class="row m-t-30">
                    <div class="col-md-12">
                        <!-- DATA TABLE-->
                        <div class="table-responsive m-b-40">
                            <table class="table table-borderless table-data3" id="myTable">
                                <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>Photo</th>
                                        <th>Address</th>
                                        <th>Country</th>
                                        <th>Telephone</th>
                                        <th>Contact</th>
                                        <th>Website</th>
                                        <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasAllRoles', $collectionOfRoles)): ?>
                                        <th>IS_Approved</th>
                                        <?php endif; ?>
                                        
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $football_group_staffs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($staff->name); ?></td>
                                    <td>
                                        <?php if($staff->user->photo): ?>
                                        <img src="<?php echo e(asset('images/' . $staff->user->photo)); ?>" alt="Photo" width="100px">
                                        <?php else: ?>
                                        No Photo
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($staff->address); ?></td>
                                    <td><?php echo e($staff->country); ?></td>
                                    <td><?php echo e($staff->telephone); ?></td>
                                    <td><?php echo e($staff->contact); ?></td>
                                    <td>
                                        <a href="<?php echo e($staff->website); ?>" target="_blank"><?php echo e($staff->website); ?></a>
                                    </td>
                                    <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasAllRoles', $collectionOfRoles)): ?>
                                    <td >
                                        <div class="dropdown">
                                            <button class="btn <?php echo e($staff->status == 'approved' ? 'btn-success' : 'btn-danger'); ?> dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                <?php echo e(ucwords(str_replace('_', ' ', $staff->status))); ?>

                                            </button>
                                            <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                              <a class="dropdown-item" href="<?php echo e(route('admin.approve.status',['id' => $staff->id, 'status' => 'approved'])); ?>">Approved</a>
                                              <a class="dropdown-item" href="<?php echo e(route('admin.approve.status', ['id' => $staff->id, 'status' => 'not_approved'])); ?>">Reject</a>
                                            
                                            </div>
                                        </div>
                                        
                                    </td>
                                    <?php endif; ?>
                                    
                                    <td class="row justify-content-between">
                                        
                                        <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasAllRoles', $collectionOfRoles)): ?>
                                        <a href="<?php echo e(route('football-group-staff.edit', $staff->id)); ?>" class="btn btn-primary btn-sm">Edit</a>
                                        <?php endif; ?>
                                        <a href="<?php echo e(route('footballGroup.export.pdf', $staff->id)); ?>" class="btn btn-success btn-sm"><i class="fa fa-print" aria-hidden="true"></i></a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <!-- END DATA TABLE-->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\My projects\Client Project\footballGroupCompany\resources\views/partials/football_group_staff/index.blade.php ENDPATH**/ ?>