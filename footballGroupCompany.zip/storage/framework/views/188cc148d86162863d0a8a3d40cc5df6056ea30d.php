
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="au-card recent-report">
                <div class="au-card-inner">
                    <?php echo $__env->make('layouts.errorAndSuccessMessage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="overview-wrap">
                    <h2 class="title-1">Players</h2>
                    </div>
                   <div class="row m-t-30">
                        <div class="col-md-12">
                            <!-- DATA TABLE-->
                            <div class="table-responsive m-b-40">
                                <table class="table table-borderless table-data3" id="myTable">
                                    <thead>
                                        <tr>
                                            <th>Photo</th>
                                            <th>Name</th>
                                            <th>Email</th>
                                            <th>Phone</th>
                                            <th>Address</th>
                                            <th>Nationality</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <?php if($player->user->photo): ?>
                                                        <img src="<?php echo e(asset('images/' . $player->user->photo)); ?>"
                                                            alt="Photo" width="100px">
                                                    <?php else: ?>
                                                        No Photo
                                                    <?php endif; ?>
                                                </td>
                                                <td><?php echo e($player->name); ?></td>
                                                <td>
                                                    <?php if(Auth::user()->football_club->payment == 'paid'): ?>
                                                    <?php echo e($player->user->email); ?>

                                                <?php else: ?>
                                                    <p>For paid user only</p>
                                                <?php endif; ?>
                                                   
                                                </td>
                                                <td>
                                                    <?php if(Auth::user()->football_club->payment == 'paid'): ?>
                                                    <?php echo e($player->phone); ?>

                                                <?php else: ?>
                                                    <p>For paid user only</p>
                                                <?php endif; ?>
                                                </td>
                                                <td>
                                                    <?php if(Auth::user()->football_club->payment == 'paid'): ?>
                                                    <?php echo e($player->address); ?>

                                                <?php else: ?>
                                                    <p>For paid user only</p>
                                                <?php endif; ?>
                                                </td>
                                                
                                                <td><?php echo e($player->nationality); ?></td>
                                                <td class="row justify-content-between">
                                                    
                                                    <a href="<?php echo e(route('player.detail', $player->id)); ?>"
                                                        class="btn btn-success btn-sm">
                                                        <i class="fa fa-eye" aria-hidden="true"></i>
                                                    </a>
                                                    <?php if(Auth::user()->football_club->payment == 'paid'): ?>
                                                    <a href="<?php echo e(route('player.pick', $player->id)); ?>"
                                                        class="btn btn-primary btn-sm m-2">
                                                        <i class="fa fa-check" aria-hidden="true"></i>
                                                    </a>
                                                    <?php else: ?>
                                                        pay to select player
                                                    <?php endif; ?>
                                                    
                                                   
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                            <!-- END DATA TABLE-->
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\My projects\Client Project\footballGroupCompany\resources\views/partials/pick_user/player_index.blade.php ENDPATH**/ ?>