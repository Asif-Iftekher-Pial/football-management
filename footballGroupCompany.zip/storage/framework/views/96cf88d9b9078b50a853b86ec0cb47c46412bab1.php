
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="au-card recent-report">
                <?php echo $__env->make('layouts.errorAndSuccessMessage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="au-card-inner">
                    <div class="overview-wrap">
                        <h2 class="title-1">overview</h2>
                        
                    </div>
                    <div class="row m-t-25">
                        <div class="col-sm-12 col-lg-12">
                            <div class="overview-item overview-item--c1">
                                <div class="overview__inner">
                                    <div class="overview-box clearfix">
                                        <div class="icon">
                                            <i class="zmdi zmdi-accounts"></i>
                                        </div>
                                        <div class="text">
                                            <h2><?php echo e($total_users); ?></h2>
                                            <span>Total Users</span>
                                        </div>
                                    </div>
                                    <div class="overview-chart">
                                        <canvas id="widget"></canvas>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6 col-lg-3">
                            <div class="overview-item overview-item--c1">
                                <div class="overview__inner">
                                    <div class="overview-box clearfix">
                                        <div class="icon">
                                            <i class="zmdi zmdi-accounts"></i>
                                        </div>
                                        <div class="text">
                                            <h2><?php echo e($active_players); ?></h2>
                                            <span>Active Players</span>
                                        </div>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6 col-lg-3">
                            <div class="overview-item overview-item--c1">
                                <div class="overview__inner">
                                    <div class="overview-box clearfix">
                                        <div class="icon">
                                            <i class="zmdi zmdi-accounts"></i>
                                        </div>
                                        <div class="text">
                                            <h2><?php echo e($inactive_players); ?></h2>
                                            <span>Inactive Players</span>
                                        </div>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6 col-lg-3">
                            <div class="overview-item overview-item--c2">
                                <div class="overview__inner">
                                    <div class="overview-box clearfix">
                                        <div class="icon">
                                            <i class="zmdi zmdi-accounts"></i>
                                        </div>
                                        <div class="text">
                                            <h2><?php echo e($active_partners); ?></h2>
                                            <span>Active Partners</span>
                                        </div>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6 col-lg-3">
                            <div class="overview-item overview-item--c2">
                                <div class="overview__inner">
                                    <div class="overview-box clearfix">
                                        <div class="icon">
                                            <i class="zmdi zmdi-accounts"></i>
                                        </div>
                                        <div class="text">
                                            <h2><?php echo e($inactive_partners); ?></h2>
                                            <span>Inactive Partners</span>
                                        </div>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6 col-lg-3">
                            <div class="overview-item overview-item--c3">
                                <div class="overview__inner">
                                    <div class="overview-box clearfix">
                                        <div class="icon">
                                            <i class="zmdi zmdi-accounts"></i>
                                        </div>
                                        <div class="text">
                                            <h2><?php echo e($active_managers); ?></h2>
                                            <span>Active Managers</span>
                                        </div>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6 col-lg-3">
                            <div class="overview-item overview-item--c3">
                                <div class="overview__inner">
                                    <div class="overview-box clearfix">
                                        <div class="icon">
                                            <i class="zmdi zmdi-accounts"></i>
                                        </div>
                                        <div class="text">
                                            <h2><?php echo e($inactive_managers); ?></h2>
                                            <span>Inactive Managers</span>
                                        </div>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6 col-lg-3">
                            <div class="overview-item overview-item--c4">
                                <div class="overview__inner">
                                    <div class="overview-box clearfix">
                                        <div class="icon">
                                            <i class="zmdi zmdi-accounts"></i>
                                        </div>
                                        <div class="text">
                                            <h2><?php echo e($active_football_staff); ?></h2>
                                            <span>Active staff</span>
                                        </div>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6 col-lg-3">
                            <div class="overview-item overview-item--c4">
                                <div class="overview__inner">
                                    <div class="overview-box clearfix">
                                        <div class="icon">
                                            <i class="zmdi zmdi-accounts"></i>
                                        </div>
                                        <div class="text">
                                            <h2><?php echo e($inactive_football_staff); ?></h2>
                                            <span>Inactive staff</span>
                                        </div>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6 col-lg-3">
                            <div class="overview-item overview-item--c2">
                                <div class="overview__inner">
                                    <div class="overview-box clearfix">
                                        <div class="icon">
                                            <i class="zmdi zmdi-accounts"></i>
                                        </div>
                                        <div class="text">
                                            <h2><?php echo e($jobs); ?></h2>
                                            <span>Active Football Jobs Member</span>
                                        </div>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6 col-lg-3">
                            <div class="overview-item overview-item--c2">
                                <div class="overview__inner">
                                    <div class="overview-box clearfix">
                                        <div class="icon">
                                            <i class="zmdi zmdi-accounts"></i>
                                        </div>
                                        <div class="text">
                                            <h2><?php echo e($inactive_jobs); ?></h2>
                                            <span>Inactive Football Jobs Members</span>
                                        </div>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
        
    </div>
    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function() {
            var chartData = <?php echo json_encode($chart_data, 15, 512) ?>;
            //WidgetChart 1
            var ctx = document.getElementById("widget");
            if (ctx) {
                ctx.height = 130;
                var myChart = new Chart(ctx, {
                    type: 'line',
                    data: {
                        labels: chartData.labels,
                        type: 'line',
                        datasets: [{
                            data: chartData.data,
                            label: 'Dataset',
                            backgroundColor: 'rgba(255,255,255,.1)',
                            borderColor: 'rgba(255,255,255,.55)',
                        }, ]
                    },
                    options: {
                        maintainAspectRatio: true,
                        legend: {
                            display: false
                        },
                        layout: {
                            padding: {
                                left: 0,
                                right: 0,
                                top: 0,
                                bottom: 0
                            }
                        },
                        responsive: true,
                        scales: {
                            xAxes: [{
                                gridLines: {
                                    color: 'transparent',
                                    zeroLineColor: 'transparent'
                                },
                                ticks: {
                                    fontSize: 2,
                                    fontColor: 'transparent'
                                }
                            }],
                            yAxes: [{
                                display: false,
                                ticks: {
                                    display: false,
                                }
                            }]
                        },
                        title: {
                            display: false,
                        },
                        elements: {
                            line: {
                                borderWidth: 0
                            },
                            point: {
                                radius: 0,
                                hitRadius: 10,
                                hoverRadius: 4
                            }
                        }
                    }
                });
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\My projects\Client Project\footballGroupCompany\resources\views/partials/home/home.blade.php ENDPATH**/ ?>